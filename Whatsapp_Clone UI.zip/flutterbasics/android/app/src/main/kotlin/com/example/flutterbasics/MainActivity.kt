package com.example.flutterbasics

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
