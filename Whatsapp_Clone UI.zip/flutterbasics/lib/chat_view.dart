import 'package:flutter/material.dart';
import 'package:flutterbasics/widgets/customStatus.dart';
import 'package:flutterbasics/widgets/customeChatTile.dart';

class ChatView extends StatelessWidget {
  const ChatView({super.key});

  @override
  Widget build(BuildContext context) {
    return DefaultTabController(
      length: 3, 
      initialIndex: 0,
      child: Scaffold(
        appBar: AppBar(
          title: const Text(
            'Hamees - WhatsApp Clone',
            style: TextStyle(
                color: Color.fromARGB(255, 10, 185, 10),
                fontWeight: FontWeight.bold,
                fontSize: 15.0),
          ),
          backgroundColor: const Color.fromARGB(235, 10, 9, 9),
          bottom: const TabBar(
            isScrollable: true,
            indicatorColor: Colors.green,
            labelColor: Colors.green,
            unselectedLabelColor: Colors.grey,
            tabs: [
              Tab(text: "CHATS"),
              Tab(text: "STATUS"),
              Tab(text: "CALLS"),
            ],
          ),
          actions: const [
            Icon(Icons.photo_camera, color: Colors.grey),
            SizedBox(width: 8),
            Icon(Icons.menu, color: Colors.white),
            SizedBox(width: 8),
          ],
        ),
        body: TabBarView(
          children: [
            // CHATS VIEW
            ListView(
              children: [
                Container(
                  color: Colors.black,
                  padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 8),
                  child: TextField(
                    decoration: InputDecoration(
                      filled: true,
                      fillColor: Colors.grey[850],
                      hintText: 'Search...',
                      hintStyle: TextStyle(color: Colors.white60),
                      border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(12),
                        borderSide: BorderSide.none,
                      ),
                      prefixIcon: Icon(Icons.search, color: Colors.white),
                    ),
                    style: TextStyle(color: Colors.white),
                  ),
                ),
                customChatTile(Colors.blueGrey, "Shahzaib", "This demo text"),
                customChatTile(Colors.blueGrey, "Jawan Pakistan App", "This demo text"),
                customChatTile(Colors.blueGrey, "Flutter Team ❤️", "This demo text xyz"),
                customChatTile(Colors.blueGrey, "Zohair - IT", "This demo text xyz"),
                customChatTile(Colors.blueGrey, "Aqsa - IT", "This demo text xyz"),
                customChatTile(Colors.blueGrey, "Ali Khan - CoreBanking", "This demo text xyz"),
                customChatTile(Colors.blueGrey, "Zariyab - Developer 👍", "This demo text xyz"),
                customChatTile(Colors.blueGrey, "Rakesh Kumar", "This demo text xyz"),
                customChatTile(Colors.blueGrey, "Hamees (you)", "This demo text xyz"),
              ],
            ),

            // STATUS VIEW
            ListView(
              children: [
                customStatus(Colors.blueGrey, "Hamees Status", "Testing only"),
                Text("Recent Updates...."),
                customStatus(Colors.blueGrey, "Hamees Status", "12:00 am"),
                customStatus(Colors.blueGrey, "Faiza", "1:00 pm"),
                customStatus(Colors.blueGrey, "Raheel", "3:45 am"),
                customStatus(Colors.blueGrey, "Mesbah - HR", "9:00 am"),
                customStatus(Colors.blueGrey, "Iqra - HR", "9:00 am"),
                customStatus(Colors.blueGrey, "Zohaib - Core", "11:00 am"),
                customStatus(Colors.blueGrey, "Aqsa - IT", "10:45 pm"),
                customStatus(Colors.blueGrey, "Hamna Abrar", "5:50 am"),
                customStatus(Colors.blueGrey, "Hamza Shaikh", "6:00 pm"),
              ],
            ),

            // CALLS VIEW
            ListView(
              children: [
                ListTile(
                  leading: Icon(Icons.call, color: Colors.green),
                  title: Text("Ali Khan", style: TextStyle(color: const Color.fromARGB(255, 30, 30, 30))),
                  subtitle: Text("Today, 2:15 PM", style: TextStyle(color: const Color.fromRGBO(77, 76, 76, 0.702))),
                  trailing: Icon(Icons.call_made, color: Colors.green),
                ),
                ListTile(
                  leading: Icon(Icons.call, color: Colors.green),
                  title: Text("Flutter Team", style: TextStyle(color: const Color.fromARGB(255, 27, 27, 27))),
                  subtitle: Text("Yesterday, 6:45 PM", style: TextStyle(color: const Color.fromRGBO(77, 76, 76, 0.702))),
                  trailing: Icon(Icons.call_received, color: Colors.red),
                ),
                ListTile(
                  leading: Icon(Icons.call, color: Colors.green),
                  title: Text("Aqsa", style: TextStyle(color: const Color.fromARGB(255, 30, 30, 30))),
                  subtitle: Text("Today, 2:15 PM", style: TextStyle(color: const Color.fromRGBO(77, 76, 76, 0.702))),
                  trailing: Icon(Icons.call_made, color: Colors.green),
                ),
                ListTile(
                  leading: Icon(Icons.call, color: Colors.green),
                  title: Text("Doctor - Imran", style: TextStyle(color: const Color.fromARGB(255, 27, 27, 27))),
                  subtitle: Text("Yesterday, 6:45 PM", style: TextStyle(color: const Color.fromRGBO(77, 76, 76, 0.702))),
                  trailing: Icon(Icons.call_received, color: Colors.red),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}
