import 'package:flutter/material.dart';
import 'package:flutterbasics/chat_view.dart';
import 'package:flutterbasics/homeview.dart';

void main()
{
    runApp(myApp());
}
class myApp extends StatelessWidget {
     myApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
        debugShowCheckedModeBanner: false,
        home: ChatView(),
    );
  }
}