import 'package:flutter/material.dart';

class Homeview extends StatelessWidget {
   Homeview({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        
        backgroundColor: Colors.blue,
          title: Text('MyTest Application'),
      ),
      body: SingleChildScrollView(
        child: Column(
          children: [
            Text('Hamees1'),
            Text('Hamees2'),
            Text('Hamees3'),
        
            Container(
              height: 200,
              width: 100,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                    color: Colors.amber,
              ),
            ),
        
            Text('Hamees1'),
            Text('Hamees2'),
            Text('Hamees3'),
        
            Container(
              height: 100,
              width: 100,
              decoration: BoxDecoration(
                shape: BoxShape.rectangle,
                    color: Colors.red,
                    boxShadow:[
                      BoxShadow(
                        color: Colors.grey.withValues(alpha: 0.5),
                        spreadRadius: 5,
                        blurRadius: 7,
                        offset: Offset(0, 3),
                      )
                    ]
              ),
            ),
        
          
            // Row(
            //   children: [
            //      Text('Hamees1'),
            //      Text('Hamees2'),
            //      Text('Hamees3'),
            //     Container(
            //       height: 100,
            //       width: 100,
            //       color: Colors.blue,
            //     ),
            //   ],
            // ),
          ],
        
        ),
      ),
      

    );
  }
}