import 'package:flutter/material.dart';

Widget customStatus(color,title,msg)
{
  return ListTile(
    leading: CircleAvatar(
      backgroundColor: color,
      backgroundImage: NetworkImage('https://www.google.com/url?sa=i&url=https%3A%2F%2Funsplash.com%2Fs%2Fphotos%2Fimage&psig=AOvVaw1iR7nm4q28JE_fCsd7RCNo&ust=1751213946129000&source=images&cd=vfe&opi=89978449&ved=0CBQQjRxqFwoTCIiU_LvClI4DFQAAAAAdAAAAABAL')
    ),
    title: Text("$title",style: TextStyle(color: const Color.fromARGB(255, 141, 140, 140)),),
    subtitle: Text("$msg"),
    tileColor: const Color.fromARGB(255, 0, 0, 0),
    subtitleTextStyle: TextStyle(color: const Color.fromARGB(255, 182, 181, 181)),
    trailing: Icon(Icons.check,size: 15,),
    iconColor: const Color.fromARGB(255, 1, 115, 245),
  );
 
}
